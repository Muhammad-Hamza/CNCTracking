package com.example.cnctracking_2.ui.report.component;

import androidx.lifecycle.ViewModel;

public class ReportViewModel extends ViewModel {
}
