package com.example.cnctracking_2.ui.maintenance.component;

import androidx.lifecycle.ViewModel;

public class MaintenanceViewModel extends ViewModel {
}
